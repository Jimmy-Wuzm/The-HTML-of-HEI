window.MINITOOL_MODE=true;document.documentElement.classList.add("minitool");
